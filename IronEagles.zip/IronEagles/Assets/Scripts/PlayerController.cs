﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	public GameObject shipOuter;
	public GameObject shipInner;
	public GameObject pauseMenu;
	private Vector3 mousePosition;
	public static bool mouseLookControls = true;
	public static bool boosting = false;
	public static bool paused = false;
	public static float velocity = 0f;
	public float health = 1000f;
	public float maxhealth = 1000f;
	public static float healthperc = 100;


	void Start () {

		mouseLookControls = false;

	}

	void FixedUpdate () {
		
		healthperc = (health / maxhealth) * 100f;
	}

	void Update () {

		if (Input.GetKey ("escape")) {

			if (paused == false) {
				paused = true;
				Time.timeScale = 0;
				pauseMenu.SetActive(true);
			}
		}
			
		if (paused == false) {
			if (mouseLookControls == true) {
				mousePosition = Input.mousePosition;
				mousePosition = Camera.main.ScreenToWorldPoint (mousePosition);

				Quaternion rot = Quaternion.LookRotation (transform.position - mousePosition, Vector3.forward);
				transform.rotation = rot;
				transform.eulerAngles = new Vector3 (0, 0, transform.eulerAngles.z);


			}
		}
	}
}
