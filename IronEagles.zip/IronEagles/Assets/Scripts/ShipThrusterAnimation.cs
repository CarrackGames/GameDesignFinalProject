﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipThrusterAnimation : MonoBehaviour {

	void Update () {

		var x = Mathf.Abs (Input.GetAxis ("Horizontal"));
		var y = Mathf.Abs (Input.GetAxis ("Vertical"));

		PlayerController.velocity = x + y;

		GetComponent<Animator> ().SetFloat ("Speed", PlayerController.velocity);
		GetComponent<Animator> ().SetBool ("Boost", PlayerController.boosting);

		if (Input.GetKeyDown ("left shift")) {
			PlayerController.boosting = true;
			PlayerShipMove.turnSpeed = 0.85f;
		}

		if (Input.GetKeyUp ("left shift")) {
			PlayerController.boosting = false;
			PlayerShipMove.turnSpeed = 2f;
		}

	}
}
