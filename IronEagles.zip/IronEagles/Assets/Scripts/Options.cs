﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Options : MonoBehaviour {
	public GameObject optionsMenu;
	public bool closeOtherMenus;

	public void OnOptionsClick(){
		closeOtherMenus = true;
		closeOtherMenus = false;
		optionsMenu.SetActive (true);
	}

	void Update(){
		if (closeOtherMenus == true) {
			optionsMenu.SetActive (false);
		}
	}
}
