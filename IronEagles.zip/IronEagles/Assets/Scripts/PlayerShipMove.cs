﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShipMove : MonoBehaviour {
	
	public static float turnSpeed = 1f;
	public float booster = 2f;
	public float speed = 1f;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void FixedUpdate () {

		var b = (Input.GetAxis ("Fire3") * booster + 1);
		var x = (Input.GetAxis ("Horizontal") * speed * b);
		var y = (Input.GetAxis ("Vertical") * speed * b);

		transform.Translate (x, y, 0);

		if (PlayerController.mouseLookControls == false) {

			var r = (Input.GetAxis ("Rotate") * turnSpeed);

			transform.Rotate (0, 0, r);
		}
	}
}
