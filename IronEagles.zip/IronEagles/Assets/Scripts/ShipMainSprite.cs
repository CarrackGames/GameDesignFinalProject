﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipMainSprite : MonoBehaviour {

	
	void Update () {

		GetComponent<Animator> ().SetFloat ("Health", PlayerController.healthperc);

	}
}
